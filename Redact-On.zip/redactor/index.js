var express = require("express");
var body_parser = require("body-parser");
var app = express();



app.use(body_parser.json());
app.use(function(req,res,next){
    res.header('Access-Control-Allow-Origin','*');
    res.header("Access-Control-Allow-Methods",'POST,GET,PUT');
    res.header('Access-Control-Allow-Headers','Content-Type');
    next();

});

app.use('/api',require('./server'));


app.listen(process.env.port || 3000 ,function (){
    console.log('now listening');

});

