var express = require("express");
var router =  express.Router();


router.post('/value',function(req,res){
console.log(req.body.value);
res.writeHead(200, {
    'Set-Cookie': 'data=test',
    'Content-Type': 'text/plain'
  });

var NaturalLanguageUnderstandingV1 = require('watson-developer-cloud/natural-language-understanding/v1.js');
var naturalLanguageUnderstanding = new NaturalLanguageUnderstandingV1({
  version: '2018-11-16',
  iam_apikey: 'XUE8cIztg6bFDJk61b9YFmV37oeAhDV-0pHkT-xNiSTV',
  url: 'https://gateway-wdc.watsonplatform.net/natural-language-understanding/api'
});

var parameters = {
    'text':req.body.value,
    'features': {
    'entities': {
         "model":"b2b137cd-bbeb-4693-a666-b5680e817e51"
    }
  }
};
var data = "";
naturalLanguageUnderstanding.analyze(parameters, function(err, response) {
  if (err)
    console.log('error:', err);
  else
    data = JSON.stringify(response, null, 2);
    console.log(JSON.stringify(response, null, 2));
    
    
});


});



module.exports = router;